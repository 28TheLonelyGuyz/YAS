package lonli;

import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.ArrayList;
import java.util.List;

import copyfiles.CopyFiles;

public class Lonli {
	
	public Lonli(String[] args) {
		if (args.length < 2) {
			System.out.println("");
			
			System.out.println("Arguments usage:");
			System.out.println("	[assets_folder] [packed_assets_file_name] [OPTIONAL : excluded_files_list_file_name]");
			System.out.println("");
			System.out.println("e.g. assets assistant.pak excluded_files.json");
			
			System.out.println("");
			System.exit(0);
		}
		
		System.out.println("");
		
		File assets = new File(args[0]);
		
		if (!(assets.exists() && assets.isDirectory())) {
			System.out.println("The file '" + assets.getName() + "' does not exist or is not a valid directory.");
			System.exit(0);
		}
		
		File packed = new File(args[1]);
		File excludedFilesList = null;
		String[] list = null;
		
		if (args.length >= 3) {
			excludedFilesList = new File(args[2]);
			
			if (!excludedFilesList.exists()) {
				System.out.println("The file '" + excludedFilesList.getName() + "' does not exist.");
				System.exit(0);
			}
			
			if (excludedFilesList.isDirectory()) {
				System.out.println("The file '" + excludedFilesList.getName() + "' should not be a directory.");
				System.exit(0);
			}
		}
		
		if (assets.list().length <= 0) {
			System.out.println("The file '" + assets.getName() + "' is empty.");
			System.exit(0);
		}
		
		if (excludedFilesList != null) {
			System.out.println("Reading excluded files list...");
			
			list = read(excludedFilesList);
			
			if (list.length <= 0) list = null;
			
			int i = 0;
			for (String file : list) {
				File f = new File(file);
				
				if (!f.exists()) list[i] = null;
				else list[i] = f.getAbsolutePath();
				
				i++;
			}
		}
		
		System.out.println("Exporting...");
		
		try {
			FileOutputStream fos = new FileOutputStream(packed);
			ZipOutputStream zos = new ZipOutputStream(fos);
			
			zipFile(assets, assets.getName(), zos, list);
			
			zos.close();
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	// https://www.baeldung.com/java-compress-and-uncompress
	public void zipFile(File file, String fileName, ZipOutputStream zos, String[] excludedList) {
		try {
			if (file.isHidden()) return;
			
			for (String e : excludedList) {
				if (file.getAbsolutePath().equals(e)) return;
			}
			
			if (file.isDirectory()) {
				if (fileName.endsWith("/")) {
					zos.putNextEntry(new ZipEntry(fileName));
					zos.closeEntry();
				} else {
					zos.putNextEntry(new ZipEntry(fileName + "/"));
					zos.closeEntry();
				}
				
				File[] children = file.listFiles();
				
				for (File childFile : children) {
					zipFile(childFile, fileName + "/" + childFile.getName(), zos, excludedList);
				}
				
				return;
			}
			
			FileInputStream fis = new FileInputStream(file);
			ZipEntry entry = new ZipEntry(fileName);
			
			zos.putNextEntry(entry);
			
			byte[] buffer = new byte[1024];
			
			int length;
			while ((length = fis.read(buffer)) > 0) {
				zos.write(buffer, 0, length);
			}
			
			fis.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public String[] read(File file) {
		try {
			FileReader reader = new FileReader(file);
			BufferedReader br = new BufferedReader(reader);
			List<String> lines = new ArrayList<>();
			
			String line;
			while ((line = br.readLine()) != null) {
				if (!line.trim().isEmpty()) lines.add(line);
			}
			
			reader.close();
			
			return lines.toArray(new String[0]);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return null;
	}
	
	public static void main(String[] args) {
		new Lonli(args);
	}
	
}